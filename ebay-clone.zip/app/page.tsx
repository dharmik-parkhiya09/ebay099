import Link from "next/link"
import { Button } from "@/components/ui/button"
import FeaturedItems from "@/components/featured-items"
import CategoryGrid from "@/components/category-grid"
import HeroSection from "@/components/hero-section"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <HeroSection />

      <section className="py-12 bg-gray-50 dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8">Popular Categories</h2>
          <CategoryGrid />
        </div>
      </section>

      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">Featured Items</h2>
            <Link href="/search">
              <Button variant="outline">View All</Button>
            </Link>
          </div>
          <FeaturedItems />
        </div>
      </section>

      <section className="py-12 bg-gray-50 dark:bg-gray-900">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Sell Your Items?</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-2xl mx-auto">
            Join thousands of sellers who have successfully sold their vintage and used items on our platform.
          </p>
          <Link href="/sell">
            <Button size="lg">Start Selling</Button>
          </Link>
        </div>
      </section>
    </div>
  )
}
