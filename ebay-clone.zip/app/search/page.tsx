"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import ProductCard from "@/components/product-card"
import { Skeleton } from "@/components/ui/skeleton"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Search, SlidersHorizontal } from "lucide-react"

// Mock data for search results
const mockAllProducts = [
  {
    id: "1",
    title: "Vintage Leather Jacket",
    price: 129.99,
    image: "/placeholder.svg?height=300&width=300",
    seller: "VintageFinds",
    condition: "Good",
    category: "Clothing",
  },
  {
    id: "2",
    title: "Antique Wooden Chair",
    price: 249.5,
    image: "/placeholder.svg?height=300&width=300",
    seller: "AntiqueLover",
    condition: "Fair",
    category: "Furniture",
  },
  {
    id: "3",
    title: "Retro Record Player",
    price: 189.0,
    image: "/placeholder.svg?height=300&width=300",
    seller: "MusicCollector",
    condition: "Excellent",
    category: "Electronics",
  },
  {
    id: "4",
    title: "Vintage Camera",
    price: 79.99,
    image: "/placeholder.svg?height=300&width=300",
    seller: "PhotoEnthusiast",
    condition: "Good",
    category: "Electronics",
  },
  {
    id: "5",
    title: "Classic Vinyl Records Collection",
    price: 120.0,
    image: "/placeholder.svg?height=300&width=300",
    seller: "MusicVault",
    condition: "Good",
    category: "Music",
  },
  {
    id: "6",
    title: "Antique Pocket Watch",
    price: 159.99,
    image: "/placeholder.svg?height=300&width=300",
    seller: "TimeKeeper",
    condition: "Excellent",
    category: "Jewelry",
  },
  {
    id: "7",
    title: "Vintage Comic Book Collection",
    price: 299.99,
    image: "/placeholder.svg?height=300&width=300",
    seller: "ComicFan",
    condition: "Good",
    category: "Books",
  },
  {
    id: "8",
    title: "Mid-Century Modern Lamp",
    price: 89.5,
    image: "/placeholder.svg?height=300&width=300",
    seller: "ModernHome",
    condition: "Good",
    category: "Furniture",
  },
  {
    id: "9",
    title: "Antique Silver Cutlery Set",
    price: 199.99,
    image: "/placeholder.svg?height=300&width=300",
    seller: "SilverCollector",
    condition: "Good",
    category: "Kitchenware",
  },
  {
    id: "10",
    title: "Vintage Polaroid Camera",
    price: 69.99,
    image: "/placeholder.svg?height=300&width=300",
    seller: "RetroTech",
    condition: "Fair",
    category: "Electronics",
  },
  {
    id: "11",
    title: "Classic Board Games Collection",
    price: 49.99,
    image: "/placeholder.svg?height=300&width=300",
    seller: "GameCollector",
    condition: "Good",
    category: "Games",
  },
  {
    id: "12",
    title: "Vintage Typewriter",
    price: 149.99,
    image: "/placeholder.svg?height=300&width=300",
    seller: "WritersCorner",
    condition: "Good",
    category: "Office",
  },
]

const conditions = ["Excellent", "Good", "Fair", "Poor"]
const categories = [
  "All",
  "Clothing",
  "Furniture",
  "Electronics",
  "Jewelry",
  "Books",
  "Music",
  "Art",
  "Kitchenware",
  "Office",
  "Games",
]

export default function SearchPage() {
  const searchParams = useSearchParams()
  const queryParam = searchParams.get("q") || ""

  const [searchQuery, setSearchQuery] = useState(queryParam)
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [priceRange, setPriceRange] = useState([0, 300])
  const [selectedConditions, setSelectedConditions] = useState<string[]>([])
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [sortBy, setSortBy] = useState("relevance")
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => {
    setLoading(true)

    // Simulate API call with a delay
    const timer = setTimeout(() => {
      let filteredProducts = [...mockAllProducts]

      // Apply search query filter
      if (queryParam) {
        filteredProducts = filteredProducts.filter(
          (product) =>
            product.title.toLowerCase().includes(queryParam.toLowerCase()) ||
            product.category.toLowerCase().includes(queryParam.toLowerCase()),
        )
      }

      // Apply price range filter
      filteredProducts = filteredProducts.filter(
        (product) => product.price >= priceRange[0] && product.price <= priceRange[1],
      )

      // Apply condition filter
      if (selectedConditions.length > 0) {
        filteredProducts = filteredProducts.filter((product) => selectedConditions.includes(product.condition))
      }

      // Apply category filter
      if (selectedCategory !== "All") {
        filteredProducts = filteredProducts.filter((product) => product.category === selectedCategory)
      }

      // Apply sorting
      if (sortBy === "price-low") {
        filteredProducts.sort((a, b) => a.price - b.price)
      } else if (sortBy === "price-high") {
        filteredProducts.sort((a, b) => b.price - a.price)
      }

      setProducts(filteredProducts)
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [queryParam, priceRange, selectedConditions, selectedCategory, sortBy])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Update URL with search query
    const url = new URL(window.location.href)
    url.searchParams.set("q", searchQuery)
    window.history.pushState({}, "", url)
  }

  const handleConditionChange = (condition: string) => {
    setSelectedConditions((prev) => {
      if (prev.includes(condition)) {
        return prev.filter((c) => c !== condition)
      } else {
        return [...prev, condition]
      }
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <form onSubmit={handleSearch} className="flex gap-2">
          <Input
            type="text"
            placeholder="Search for items..."
            className="flex-1"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Button type="submit">
            <Search className="h-4 w-4 mr-2" />
            Search
          </Button>
          <Button type="button" variant="outline" className="md:hidden" onClick={() => setShowFilters(!showFilters)}>
            <SlidersHorizontal className="h-4 w-4" />
          </Button>
        </form>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Filters - Desktop */}
        <div className="w-full md:w-64 hidden md:block">
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold mb-3">Price Range</h3>
              <div className="px-2">
                <Slider defaultValue={[0, 300]} max={300} step={10} value={priceRange} onValueChange={setPriceRange} />
                <div className="flex justify-between mt-2 text-sm">
                  <span>${priceRange[0]}</span>
                  <span>${priceRange[1]}</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3">Condition</h3>
              <div className="space-y-2">
                {conditions.map((condition) => (
                  <div key={condition} className="flex items-center">
                    <Checkbox
                      id={`condition-${condition}`}
                      checked={selectedConditions.includes(condition)}
                      onCheckedChange={() => handleConditionChange(condition)}
                    />
                    <label
                      htmlFor={`condition-${condition}`}
                      className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      {condition}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3">Category</h3>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Filters - Mobile */}
        {showFilters && (
          <div className="md:hidden mb-4">
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="price">
                <AccordionTrigger>Price Range</AccordionTrigger>
                <AccordionContent>
                  <div className="px-2">
                    <Slider
                      defaultValue={[0, 300]}
                      max={300}
                      step={10}
                      value={priceRange}
                      onValueChange={setPriceRange}
                    />
                    <div className="flex justify-between mt-2 text-sm">
                      <span>${priceRange[0]}</span>
                      <span>${priceRange[1]}</span>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="condition">
                <AccordionTrigger>Condition</AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2">
                    {conditions.map((condition) => (
                      <div key={condition} className="flex items-center">
                        <Checkbox
                          id={`mobile-condition-${condition}`}
                          checked={selectedConditions.includes(condition)}
                          onCheckedChange={() => handleConditionChange(condition)}
                        />
                        <label
                          htmlFor={`mobile-condition-${condition}`}
                          className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {condition}
                        </label>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="category">
                <AccordionTrigger>Category</AccordionTrigger>
                <AccordionContent>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        )}

        {/* Results */}
        <div className="flex-1">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold">{loading ? "Searching..." : `${products.length} Results`}</h2>
            <div className="flex items-center">
              <span className="mr-2 text-sm hidden md:inline">Sort by:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevance">Relevance</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(6)
                .fill(0)
                .map((_, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <Skeleton className="h-48 w-full rounded-md mb-4" />
                    <Skeleton className="h-4 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-4" />
                    <Skeleton className="h-8 w-28" />
                  </div>
                ))}
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-12">
              <h3 className="text-xl font-semibold mb-2">No items found</h3>
              <p className="text-gray-600 dark:text-gray-400">Try adjusting your search or filter criteria</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
