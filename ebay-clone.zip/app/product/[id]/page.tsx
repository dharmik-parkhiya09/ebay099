import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import AddToCartButton from "@/components/add-to-cart-button"
import RelatedProducts from "@/components/related-products"

// Mock data for a single product
const getProductById = (id: string) => {
  return {
    id,
    title: "Vintage Leather Jacket",
    description:
      "A beautiful vintage leather jacket from the 1970s. This jacket features a classic design with minimal wear and tear. Perfect for collectors or anyone looking for a unique piece of clothing with history.",
    price: 129.99,
    seller: "VintageFinds",
    sellerRating: 4.8,
    condition: "Good",
    category: "Clothing",
    location: "Portland, OR",
    listedDate: "2023-04-15",
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    details: {
      brand: "Classic Leather",
      size: "Medium",
      color: "Brown",
      material: "Genuine Leather",
      era: "1970s",
    },
    shipping: {
      domestic: 12.99,
      international: 29.99,
      handlingTime: "1-2 business days",
    },
  }
}

export default function ProductPage({ params }: { params: { id: string } }) {
  const product = getProductById(params.id)

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="relative aspect-square rounded-lg overflow-hidden border">
            <Image
              src={product.images[0] || "/placeholder.svg"}
              alt={product.title}
              fill
              className="object-cover"
              priority
            />
          </div>
          <div className="grid grid-cols-3 gap-2">
            {product.images.slice(1).map((image, index) => (
              <div key={index} className="relative aspect-square rounded-lg overflow-hidden border">
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`${product.title} - view ${index + 2}`}
                  fill
                  className="object-cover"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div>
          <h1 className="text-3xl font-bold mb-2">{product.title}</h1>
          <div className="flex items-center mb-4">
            <Badge variant="outline" className="mr-2">
              {product.condition}
            </Badge>
            <Badge variant="outline">{product.category}</Badge>
          </div>
          <p className="text-2xl font-bold mb-4">${product.price.toFixed(2)}</p>

          <div className="mb-6">
            <p className="text-gray-700 dark:text-gray-300">{product.description}</p>
          </div>

          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex justify-between py-2 border-b">
                <span className="font-medium">Seller</span>
                <span>
                  {product.seller} ({product.sellerRating}★)
                </span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="font-medium">Location</span>
                <span>{product.location}</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="font-medium">Listed</span>
                <span>{product.listedDate}</span>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-4">
            <AddToCartButton product={product} />
            <Button variant="outline" className="w-full">
              Make Offer
            </Button>
            <Button variant="outline" className="w-full">
              Contact Seller
            </Button>
          </div>
        </div>
      </div>

      {/* Product Details Tabs */}
      <div className="mt-12">
        <Tabs defaultValue="details">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="details">Item Details</TabsTrigger>
            <TabsTrigger value="shipping">Shipping</TabsTrigger>
            <TabsTrigger value="returns">Returns</TabsTrigger>
          </TabsList>
          <TabsContent value="details" className="p-4 border rounded-b-lg">
            <div className="grid grid-cols-2 gap-4">
              {Object.entries(product.details).map(([key, value]) => (
                <div key={key} className="flex justify-between py-2 border-b">
                  <span className="font-medium capitalize">{key}</span>
                  <span>{value}</span>
                </div>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="shipping" className="p-4 border rounded-b-lg">
            <div className="space-y-4">
              <div className="flex justify-between py-2 border-b">
                <span className="font-medium">Domestic Shipping</span>
                <span>${product.shipping.domestic.toFixed(2)}</span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="font-medium">International Shipping</span>
                <span>${product.shipping.international.toFixed(2)}</span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="font-medium">Handling Time</span>
                <span>{product.shipping.handlingTime}</span>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="returns" className="p-4 border rounded-b-lg">
            <p>This seller accepts returns within 14 days of delivery. Buyer pays return shipping costs.</p>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold mb-6">Similar Items You May Like</h2>
        <RelatedProducts category={product.category} currentProductId={product.id} />
      </div>
    </div>
  )
}
