"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Package, ShoppingBag, Heart, Settings, CreditCard, MessageSquare, Star } from "lucide-react"

// Mock user data
const userData = {
  name: "Jane Smith",
  email: "jane.smith@example.com",
  joined: "April 2023",
  avatar: "/placeholder.svg?height=100&width=100",
  stats: {
    purchases: 12,
    sales: 8,
    favorites: 24,
    rating: 4.8,
  },
}

// Mock recent purchases
const recentPurchases = [
  {
    id: "p1",
    title: "Vintage Camera",
    price: 79.99,
    date: "2023-05-15",
    status: "Delivered",
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "p2",
    title: "Antique Pocket Watch",
    price: 159.99,
    date: "2023-04-28",
    status: "Delivered",
    image: "/placeholder.svg?height=80&width=80",
  },
]

// Mock active listings
const activeListings = [
  {
    id: "l1",
    title: "Vintage Leather Jacket",
    price: 129.99,
    date: "2023-05-01",
    views: 45,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "l2",
    title: "Classic Vinyl Records Collection",
    price: 120.0,
    date: "2023-05-10",
    views: 32,
    image: "/placeholder.svg?height=80&width=80",
  },
]

export default function AccountPage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar */}
        <div className="w-full md:w-64">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center mb-6">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src={userData.avatar} alt={userData.name} />
                  <AvatarFallback>{userData.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <h2 className="text-xl font-bold">{userData.name}</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400">Member since {userData.joined}</p>
              </div>

              <nav className="space-y-1">
                <Button
                  variant={activeTab === "overview" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveTab("overview")}
                >
                  <Package className="mr-2 h-4 w-4" />
                  Overview
                </Button>
                <Button
                  variant={activeTab === "purchases" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveTab("purchases")}
                >
                  <ShoppingBag className="mr-2 h-4 w-4" />
                  Purchases
                </Button>
                <Button
                  variant={activeTab === "listings" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveTab("listings")}
                >
                  <Package className="mr-2 h-4 w-4" />
                  My Listings
                </Button>
                <Button
                  variant={activeTab === "favorites" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveTab("favorites")}
                >
                  <Heart className="mr-2 h-4 w-4" />
                  Favorites
                </Button>
                <Button
                  variant={activeTab === "messages" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveTab("messages")}
                >
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Messages
                </Button>
                <Button
                  variant={activeTab === "payment" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveTab("payment")}
                >
                  <CreditCard className="mr-2 h-4 w-4" />
                  Payment Methods
                </Button>
                <Button
                  variant={activeTab === "settings" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setActiveTab("settings")}
                >
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </Button>
              </nav>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="flex-1">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-4 md:grid-cols-7 mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="purchases">Purchases</TabsTrigger>
              <TabsTrigger value="listings">Listings</TabsTrigger>
              <TabsTrigger value="favorites">Favorites</TabsTrigger>
              <TabsTrigger value="messages" className="hidden md:block">
                Messages
              </TabsTrigger>
              <TabsTrigger value="payment" className="hidden md:block">
                Payment
              </TabsTrigger>
              <TabsTrigger value="settings" className="hidden md:block">
                Settings
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Account Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex flex-col items-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <ShoppingBag className="h-8 w-8 text-gray-500 mb-2" />
                        <span className="text-2xl font-bold">{userData.stats.purchases}</span>
                        <span className="text-sm text-gray-500">Purchases</span>
                      </div>
                      <div className="flex flex-col items-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <Package className="h-8 w-8 text-gray-500 mb-2" />
                        <span className="text-2xl font-bold">{userData.stats.sales}</span>
                        <span className="text-sm text-gray-500">Sales</span>
                      </div>
                      <div className="flex flex-col items-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <Heart className="h-8 w-8 text-gray-500 mb-2" />
                        <span className="text-2xl font-bold">{userData.stats.favorites}</span>
                        <span className="text-sm text-gray-500">Favorites</span>
                      </div>
                      <div className="flex flex-col items-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <Star className="h-8 w-8 text-gray-500 mb-2" />
                        <span className="text-2xl font-bold">{userData.stats.rating}</span>
                        <span className="text-sm text-gray-500">Rating</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Recent Purchases</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {recentPurchases.length > 0 ? (
                      <div className="space-y-4">
                        {recentPurchases.map((purchase) => (
                          <div key={purchase.id} className="flex items-center gap-4">
                            <div className="w-16 h-16 relative rounded overflow-hidden flex-shrink-0">
                              <img
                                src={purchase.image || "/placeholder.svg"}
                                alt={purchase.title}
                                className="object-cover w-full h-full"
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium truncate">{purchase.title}</h4>
                              <div className="flex justify-between text-sm text-gray-500">
                                <span>${purchase.price.toFixed(2)}</span>
                                <span>{purchase.status}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                        <Link href="/account/purchases">
                          <Button variant="link" className="w-full">
                            View All Purchases
                          </Button>
                        </Link>
                      </div>
                    ) : (
                      <p className="text-center py-4 text-gray-500">No recent purchases</p>
                    )}
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>Active Listings</CardTitle>
                </CardHeader>
                <CardContent>
                  {activeListings.length > 0 ? (
                    <div className="space-y-4">
                      {activeListings.map((listing) => (
                        <div key={listing.id} className="flex items-center gap-4">
                          <div className="w-16 h-16 relative rounded overflow-hidden flex-shrink-0">
                            <img
                              src={listing.image || "/placeholder.svg"}
                              alt={listing.title}
                              className="object-cover w-full h-full"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium truncate">{listing.title}</h4>
                            <div className="flex justify-between text-sm text-gray-500">
                              <span>${listing.price.toFixed(2)}</span>
                              <span>{listing.views} views</span>
                            </div>
                          </div>
                          <Link href={`/product/${listing.id}`}>
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                          </Link>
                        </div>
                      ))}
                      <div className="flex justify-between pt-4">
                        <Link href="/account/listings">
                          <Button variant="link">View All Listings</Button>
                        </Link>
                        <Link href="/sell">
                          <Button>Create New Listing</Button>
                        </Link>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500 mb-4">You don't have any active listings</p>
                      <Link href="/sell">
                        <Button>Create Your First Listing</Button>
                      </Link>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="purchases">
              <Card>
                <CardHeader>
                  <CardTitle>Purchase History</CardTitle>
                  <CardDescription>View and manage your purchases</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-center py-8 text-gray-500">Purchase history content will be displayed here</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="listings">
              <Card>
                <CardHeader>
                  <CardTitle>My Listings</CardTitle>
                  <CardDescription>Manage your active and sold listings</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-center py-8 text-gray-500">Listings content will be displayed here</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="favorites">
              <Card>
                <CardHeader>
                  <CardTitle>Favorites</CardTitle>
                  <CardDescription>Items you've saved for later</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-center py-8 text-gray-500">Favorites content will be displayed here</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="messages">
              <Card>
                <CardHeader>
                  <CardTitle>Messages</CardTitle>
                  <CardDescription>Communicate with buyers and sellers</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-center py-8 text-gray-500">Messages content will be displayed here</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="payment">
              <Card>
                <CardHeader>
                  <CardTitle>Payment Methods</CardTitle>
                  <CardDescription>Manage your payment options</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-center py-8 text-gray-500">Payment methods content will be displayed here</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                  <CardDescription>Manage your account preferences</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-center py-8 text-gray-500">Settings content will be displayed here</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
