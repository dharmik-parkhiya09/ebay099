// This is a mock database service
// In a real application, you would connect to a real database like MongoDB

export interface User {
  id: string
  name: string
  email: string
  password: string // In a real app, this would be hashed
  createdAt: Date
  avatar?: string
}

export interface Product {
  id: string
  title: string
  description: string
  price: number
  images: string[]
  sellerId: string
  sellerName: string
  condition: string
  category: string
  location?: string
  createdAt: Date
  views: number
  status: "active" | "sold" | "draft"
}

export interface Order {
  id: string
  productId: string
  buyerId: string
  sellerId: string
  price: number
  status: "pending" | "paid" | "shipped" | "delivered" | "cancelled"
  createdAt: Date
  updatedAt: Date
}

// Mock data
const users: User[] = [
  {
    id: "1",
    name: "Jane Smith",
    email: "jane.smith@example.com",
    password: "password123",
    createdAt: new Date("2023-04-01"),
    avatar: "/placeholder.svg?height=100&width=100",
  },
]

let products: Product[] = [
  {
    id: "1",
    title: "Vintage Leather Jacket",
    description:
      "A beautiful vintage leather jacket from the 1970s. This jacket features a classic design with minimal wear and tear.",
    price: 129.99,
    images: ["/placeholder.svg?height=600&width=600", "/placeholder.svg?height=600&width=600"],
    sellerId: "1",
    sellerName: "VintageFinds",
    condition: "Good",
    category: "Clothing",
    location: "Portland, OR",
    createdAt: new Date("2023-05-01"),
    views: 45,
    status: "active",
  },
  {
    id: "2",
    title: "Antique Wooden Chair",
    description:
      "Beautiful antique wooden chair with intricate carvings. Perfect for collectors or as a statement piece.",
    price: 249.5,
    images: ["/placeholder.svg?height=600&width=600"],
    sellerId: "1",
    sellerName: "AntiqueLover",
    condition: "Fair",
    category: "Furniture",
    location: "Seattle, WA",
    createdAt: new Date("2023-04-15"),
    views: 32,
    status: "active",
  },
]

const orders: Order[] = [
  {
    id: "1",
    productId: "3",
    buyerId: "1",
    sellerId: "2",
    price: 79.99,
    status: "delivered",
    createdAt: new Date("2023-05-15"),
    updatedAt: new Date("2023-05-20"),
  },
]

// Mock database functions
export async function getUsers(): Promise<User[]> {
  return users
}

export async function getUserById(id: string): Promise<User | null> {
  return users.find((user) => user.id === id) || null
}

export async function getProducts(limit?: number): Promise<Product[]> {
  return limit ? products.slice(0, limit) : products
}

export async function getProductById(id: string): Promise<Product | null> {
  return products.find((product) => product.id === id) || null
}

export async function getProductsByCategory(category: string): Promise<Product[]> {
  return products.filter((product) => product.category === category)
}

export async function searchProducts(query: string): Promise<Product[]> {
  const lowerQuery = query.toLowerCase()
  return products.filter(
    (product) =>
      product.title.toLowerCase().includes(lowerQuery) ||
      product.description.toLowerCase().includes(lowerQuery) ||
      product.category.toLowerCase().includes(lowerQuery),
  )
}

export async function createProduct(product: Omit<Product, "id" | "createdAt" | "views" | "status">): Promise<Product> {
  const newProduct: Product = {
    ...product,
    id: Date.now().toString(),
    createdAt: new Date(),
    views: 0,
    status: "active",
  }

  products.push(newProduct)
  return newProduct
}

export async function updateProduct(id: string, updates: Partial<Product>): Promise<Product | null> {
  const index = products.findIndex((product) => product.id === id)
  if (index === -1) return null

  products[index] = { ...products[index], ...updates }
  return products[index]
}

export async function deleteProduct(id: string): Promise<boolean> {
  const initialLength = products.length
  products = products.filter((product) => product.id !== id)
  return products.length < initialLength
}

export async function getOrders(): Promise<Order[]> {
  return orders
}

export async function getOrderById(id: string): Promise<Order | null> {
  return orders.find((order) => order.id === id) || null
}

export async function createOrder(order: Omit<Order, "id" | "createdAt" | "updatedAt">): Promise<Order> {
  const now = new Date()
  const newOrder: Order = {
    ...order,
    id: Date.now().toString(),
    createdAt: now,
    updatedAt: now,
  }

  orders.push(newOrder)
  return newOrder
}

export async function updateOrder(id: string, updates: Partial<Order>): Promise<Order | null> {
  const index = orders.findIndex((order) => order.id === id)
  if (index === -1) return null

  orders[index] = {
    ...orders[index],
    ...updates,
    updatedAt: new Date(),
  }

  return orders[index]
}
