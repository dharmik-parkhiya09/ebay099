"use client"

import { useState, useEffect } from "react"
import ProductCard from "./product-card"
import { Skeleton } from "@/components/ui/skeleton"

// Mock data for featured products
const mockProducts = [
  {
    id: "1",
    title: "Vintage Leather Jacket",
    price: 129.99,
    image: "/placeholder.svg?height=300&width=300",
    seller: "VintageFinds",
    condition: "Good",
    category: "Clothing",
  },
  {
    id: "2",
    title: "Antique Wooden Chair",
    price: 249.5,
    image: "/placeholder.svg?height=300&width=300",
    seller: "AntiqueLover",
    condition: "Fair",
    category: "Furniture",
  },
  {
    id: "3",
    title: "Retro Record Player",
    price: 189.0,
    image: "/placeholder.svg?height=300&width=300",
    seller: "MusicCollector",
    condition: "Excellent",
    category: "Electronics",
  },
  {
    id: "4",
    title: "Vintage Camera",
    price: 79.99,
    image: "/placeholder.svg?height=300&width=300",
    seller: "PhotoEnthusiast",
    condition: "Good",
    category: "Electronics",
  },
  {
    id: "5",
    title: "Classic Vinyl Records Collection",
    price: 120.0,
    image: "/placeholder.svg?height=300&width=300",
    seller: "MusicVault",
    condition: "Good",
    category: "Music",
  },
  {
    id: "6",
    title: "Antique Pocket Watch",
    price: 159.99,
    image: "/placeholder.svg?height=300&width=300",
    seller: "TimeKeeper",
    condition: "Excellent",
    category: "Jewelry",
  },
  {
    id: "7",
    title: "Vintage Comic Book Collection",
    price: 299.99,
    image: "/placeholder.svg?height=300&width=300",
    seller: "ComicFan",
    condition: "Good",
    category: "Books",
  },
  {
    id: "8",
    title: "Mid-Century Modern Lamp",
    price: 89.5,
    image: "/placeholder.svg?height=300&width=300",
    seller: "ModernHome",
    condition: "Good",
    category: "Furniture",
  },
]

export default function FeaturedItems() {
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate API call with a delay
    const timer = setTimeout(() => {
      setProducts(mockProducts)
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {Array(8)
          .fill(0)
          .map((_, index) => (
            <div key={index} className="border rounded-lg p-4">
              <Skeleton className="h-48 w-full rounded-md mb-4" />
              <Skeleton className="h-4 w-3/4 mb-2" />
              <Skeleton className="h-4 w-1/2 mb-4" />
              <Skeleton className="h-8 w-28" />
            </div>
          ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  )
}
