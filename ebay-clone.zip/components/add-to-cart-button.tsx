"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Check, Minus, Plus } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Product {
  id: string
  title: string
  price: number
  [key: string]: any
}

export default function AddToCartButton({ product }: { product: Product }) {
  const [quantity, setQuantity] = useState(1)
  const [isAdding, setIsAdding] = useState(false)
  const { toast } = useToast()

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  const increaseQuantity = () => {
    setQuantity(quantity + 1)
  }

  const addToCart = () => {
    setIsAdding(true)

    // Simulate API call
    setTimeout(() => {
      setIsAdding(false)

      toast({
        title: "Added to cart",
        description: `${quantity} x ${product.title} has been added to your cart`,
        duration: 3000,
      })
    }, 1000)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center">
        <Button variant="outline" size="icon" onClick={decreaseQuantity} disabled={quantity <= 1}>
          <Minus className="h-4 w-4" />
        </Button>
        <span className="mx-4 font-medium w-8 text-center">{quantity}</span>
        <Button variant="outline" size="icon" onClick={increaseQuantity}>
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      <Button className="w-full" size="lg" onClick={addToCart} disabled={isAdding}>
        {isAdding ? <Check className="mr-2 h-4 w-4" /> : <ShoppingCart className="mr-2 h-4 w-4" />}
        {isAdding ? "Added to Cart" : "Add to Cart"}
      </Button>
    </div>
  )
}
