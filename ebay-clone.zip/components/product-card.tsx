"use client"

import type React from "react"

import Image from "next/image"
import Link from "next/link"
import { Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

interface Product {
  id: string
  title: string
  price: number
  image: string
  seller: string
  condition: string
  category: string
}

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  const [isFavorite, setIsFavorite] = useState(false)
  const { toast } = useToast()

  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsFavorite(!isFavorite)

    toast({
      title: isFavorite ? "Removed from favorites" : "Added to favorites",
      description: isFavorite
        ? `${product.title} has been removed from your favorites`
        : `${product.title} has been added to your favorites`,
      duration: 3000,
    })
  }

  const addToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    toast({
      title: "Added to cart",
      description: `${product.title} has been added to your cart`,
      duration: 3000,
    })
  }

  return (
    <Link href={`/product/${product.id}`}>
      <Card className="overflow-hidden h-full transition-all hover:shadow-md">
        <div className="relative aspect-square">
          <Image src={product.image || "/placeholder.svg"} alt={product.title} fill className="object-cover" />
          <button
            onClick={toggleFavorite}
            className="absolute top-2 right-2 p-1.5 bg-white dark:bg-gray-800 rounded-full shadow-sm"
          >
            <Heart className={`h-5 w-5 ${isFavorite ? "fill-red-500 text-red-500" : "text-gray-500"}`} />
          </button>
        </div>
        <CardContent className="p-4">
          <h3 className="font-semibold text-lg line-clamp-1">{product.title}</h3>
          <p className="text-lg font-bold mt-1">${product.price.toFixed(2)}</p>
          <div className="flex items-center justify-between mt-2 text-sm text-gray-500 dark:text-gray-400">
            <span>{product.seller}</span>
            <span>{product.condition}</span>
          </div>
        </CardContent>
        <CardFooter className="p-4 pt-0">
          <Button onClick={addToCart} className="w-full">
            Add to Cart
          </Button>
        </CardFooter>
      </Card>
    </Link>
  )
}
