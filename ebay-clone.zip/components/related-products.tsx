"use client"

import { useState, useEffect } from "react"
import ProductCard from "./product-card"
import { Skeleton } from "@/components/ui/skeleton"

// Mock data for related products
const mockRelatedProducts = {
  Clothing: [
    {
      id: "8",
      title: "Vintage Denim Jacket",
      price: 89.99,
      image: "/placeholder.svg?height=300&width=300",
      seller: "RetroClothes",
      condition: "Excellent",
      category: "Clothing",
    },
    {
      id: "9",
      title: "Classic Wool Coat",
      price: 149.99,
      image: "/placeholder.svg?height=300&width=300",
      seller: "VintageVault",
      condition: "Good",
      category: "Clothing",
    },
    {
      id: "10",
      title: "Retro Band T-Shirt",
      price: 34.99,
      image: "/placeholder.svg?height=300&width=300",
      seller: "MusicMemorabilia",
      condition: "Good",
      category: "Clothing",
    },
    {
      id: "11",
      title: "Vintage Leather Boots",
      price: 119.99,
      image: "/placeholder.svg?height=300&width=300",
      seller: "ClassicFootwear",
      condition: "Fair",
      category: "Clothing",
    },
  ],
  Furniture: [
    {
      id: "12",
      title: "Mid-Century Coffee Table",
      price: 199.99,
      image: "/placeholder.svg?height=300&width=300",
      seller: "RetroHome",
      condition: "Good",
      category: "Furniture",
    },
    {
      id: "13",
      title: "Vintage Bookshelf",
      price: 149.99,
      image: "/placeholder.svg?height=300&width=300",
      seller: "AntiqueFurniture",
      condition: "Good",
      category: "Furniture",
    },
    {
      id: "14",
      title: "Retro Dining Chairs (Set of 4)",
      price: 299.99,
      image: "/placeholder.svg?height=300&width=300",
      seller: "VintageHome",
      condition: "Fair",
      category: "Furniture",
    },
    {
      id: "15",
      title: "Antique Side Table",
      price: 89.99,
      image: "/placeholder.svg?height=300&width=300",
      seller: "ClassicInteriors",
      condition: "Good",
      category: "Furniture",
    },
  ],
  Electronics: [
    {
      id: "16",
      title: "Vintage Turntable",
      price: 249.99,
      image: "/placeholder.svg?height=300&width=300",
      seller: "AudioCollector",
      condition: "Good",
      category: "Electronics",
    },
    {
      id: "17",
      title: "Classic Film Camera",
      price: 129.99,
      image: "/placeholder.svg?height=300&width=300",
      seller: "RetroTech",
      condition: "Excellent",
      category: "Electronics",
    },
    {
      id: "18",
      title: "Retro Gaming Console",
      price: 179.99,
      image: "/placeholder.svg?height=300&width=300",
      seller: "GamerVintage",
      condition: "Good",
      category: "Electronics",
    },
    {
      id: "19",
      title: "Vintage Radio",
      price: 69.99,
      image: "/placeholder.svg?height=300&width=300",
      seller: "ClassicElectronics",
      condition: "Fair",
      category: "Electronics",
    },
  ],
}

interface RelatedProductsProps {
  category: string
  currentProductId: string
}

export default function RelatedProducts({ category, currentProductId }: RelatedProductsProps) {
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate API call with a delay
    const timer = setTimeout(() => {
      const relatedProducts = mockRelatedProducts[category as keyof typeof mockRelatedProducts] || []
      // Filter out current product if it's in the related products
      const filteredProducts = relatedProducts.filter((product) => product.id !== currentProductId)
      setProducts(filteredProducts)
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [category, currentProductId])

  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {Array(4)
          .fill(0)
          .map((_, index) => (
            <div key={index} className="border rounded-lg p-4">
              <Skeleton className="h-48 w-full rounded-md mb-4" />
              <Skeleton className="h-4 w-3/4 mb-2" />
              <Skeleton className="h-4 w-1/2 mb-4" />
              <Skeleton className="h-8 w-28" />
            </div>
          ))}
      </div>
    )
  }

  if (products.length === 0) {
    return <p>No related products found.</p>
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  )
}
