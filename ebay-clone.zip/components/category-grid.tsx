import Link from "next/link"
import { Watch, BookOpen, Tv, Shirt, Sofa, Gem, Palette, Gamepad2 } from "lucide-react"

const categories = [
  {
    name: "Antiques",
    icon: <Watch className="h-8 w-8 mb-2" />,
    slug: "antiques",
    color: "bg-amber-100 dark:bg-amber-950",
    textColor: "text-amber-800 dark:text-amber-300",
  },
  {
    name: "Books",
    icon: <BookOpen className="h-8 w-8 mb-2" />,
    slug: "books",
    color: "bg-blue-100 dark:bg-blue-950",
    textColor: "text-blue-800 dark:text-blue-300",
  },
  {
    name: "Electronics",
    icon: <Tv className="h-8 w-8 mb-2" />,
    slug: "electronics",
    color: "bg-purple-100 dark:bg-purple-950",
    textColor: "text-purple-800 dark:text-purple-300",
  },
  {
    name: "Clothing",
    icon: <Shirt className="h-8 w-8 mb-2" />,
    slug: "clothing",
    color: "bg-green-100 dark:bg-green-950",
    textColor: "text-green-800 dark:text-green-300",
  },
  {
    name: "Furniture",
    icon: <Sofa className="h-8 w-8 mb-2" />,
    slug: "furniture",
    color: "bg-orange-100 dark:bg-orange-950",
    textColor: "text-orange-800 dark:text-orange-300",
  },
  {
    name: "Jewelry",
    icon: <Gem className="h-8 w-8 mb-2" />,
    slug: "jewelry",
    color: "bg-pink-100 dark:bg-pink-950",
    textColor: "text-pink-800 dark:text-pink-300",
  },
  {
    name: "Art",
    icon: <Palette className="h-8 w-8 mb-2" />,
    slug: "art",
    color: "bg-red-100 dark:bg-red-950",
    textColor: "text-red-800 dark:text-red-300",
  },
  {
    name: "Gaming",
    icon: <Gamepad2 className="h-8 w-8 mb-2" />,
    slug: "gaming",
    color: "bg-indigo-100 dark:bg-indigo-950",
    textColor: "text-indigo-800 dark:text-indigo-300",
  },
]

export default function CategoryGrid() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {categories.map((category) => (
        <Link
          key={category.slug}
          href={`/categories/${category.slug}`}
          className={`${category.color} ${category.textColor} p-6 rounded-lg text-center transition-transform hover:scale-105`}
        >
          <div className="flex flex-col items-center">
            {category.icon}
            <h3 className="font-semibold">{category.name}</h3>
          </div>
        </Link>
      ))}
    </div>
  )
}
