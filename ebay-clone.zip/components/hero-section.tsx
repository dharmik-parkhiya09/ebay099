import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function HeroSection() {
  return (
    <section className="relative bg-gradient-to-r from-gray-900 to-gray-800 text-white py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Discover Unique Vintage Treasures</h1>
          <p className="text-xl mb-8 text-gray-300">
            Buy and sell pre-loved items with character and history. From antiques to collectibles, find something
            special today.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link href="/search">
              <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-200">
                Browse Items
              </Button>
            </Link>
            <Link href="/sell">
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-gray-900"
              >
                Start Selling
              </Button>
            </Link>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 right-0 w-1/3 h-full hidden lg:block">
        <div className="w-full h-full bg-[url('/placeholder.svg?height=600&width=500')] bg-cover bg-center opacity-20"></div>
      </div>
    </section>
  )
}
